open OUnit2
open Types
open Eval

let make_eval_test
    (name:string)
    (env:env)
    (exp:exp)
    (exp_val:value) =
  name >:: (fun _ -> assert_equal exp_val (eval env exp))

let make_eval_test_exn
    (name:string)
    (env:env)
    (exp:exp)
    (exp_exn:exn) = 
  name >:: (fun _ -> assert_raises exp_exn (fun _ -> eval env exp))

let suite = "interpreter test suite" >::: [
    make_eval_test "eval unit" [] Unit VUnit;
    make_eval_test "eval bool" [] (Bool(true)) (VBool(true));
    make_eval_test "eval pair" [] (Pair(Int(42), Int(21))) 
      (VPair(VInt(42), VInt(21)));
    make_eval_test "eval int" [] (Int(42)) (VInt(42));
    make_eval_test "eval string" [] (Str("hello")) (VStr("hello"));
    make_eval_test "eval var" [("v", VInt(20))] (Var("v")) (VInt(20));
    make_eval_test "eval fun" [] (Fun(PUnit, Int(42))) 
      (VFun(PUnit, Int(42), []));
    make_eval_test "eval string_of_int app" [] 
      (App(Var("string_of_int"), Int(42))) (VStr("42"));
    make_eval_test "eval random app" [] (App(Var("random"), Int(1))) (VInt(0));

    (* the following tests test expressions that evaluate to a unit and have 
       an effect. 
       it is only tested that a unit is returned, since it would be very 
       difficult
       if not impossible to test whether or not the effect has been undergone. 
    *)
    make_eval_test "eval print app" [] (App(Var("print"), Int(42))) (VUnit);
    make_eval_test "eval println app" [] (App(Var("println"), Str("hello"))) 
      (VUnit);
    make_eval_test "eval print_detail1 app" [] 
      (App(Var("print_detail1"), Str("hello"))) (VUnit);
    make_eval_test "eval print_detail2 app" [] 
      (App(Var("print_detail2"), Str("hello"))) (VUnit);
    make_eval_test "eval print_detail3 app" [] 
      (App(Var("print_detail3"), Str("hello"))) (VUnit);
    make_eval_test "eval ignore app" [] 
      (App(Var("ignore"), Str("hello world"))) (VUnit);

    make_eval_test "eval let" [] 
      (Let(PVar("x"), Int(30), Bin(Add, Int(2), Var("x")))) (VInt(32));
    make_eval_test "eval letrec" [] 
      (LetRec("x", Fun(PUnit, Int(30)), Int(20))) (VInt(20));

    make_eval_test "eval nil" [] (Nil) (VNil);
    make_eval_test "eval cons" [] 
      (Cons(Int(30),Int(40))) (VCons(VInt(30),VInt(40)));
    make_eval_test "eval assign" [] (Assign(Ref(Int(2)), Int(3))) (VUnit);
    make_eval_test "eval ref" [] (Ref(Int(2))) (VRef(ref (VInt(2))));
    make_eval_test "eval deref" [] (Deref(Ref(Int(2)))) (VInt(2));

    make_eval_test "eval add binop" [] (Bin(Add,Int(30),Int(40))) (VInt(70));
    make_eval_test "eval sub binop" [] (Bin(Sub,Int(30),Int(40))) (VInt(-10));
    make_eval_test "eval mul binop" [] (Bin(Mul,Int(3),Int(4))) (VInt(12));
    make_eval_test "eval div binop" [] (Bin(Div,Int(10),Int(5))) (VInt(2));
    make_eval_test "eval mod binop" [] (Bin(Mod,Int(10),Int(4))) (VInt(2));
    make_eval_test "eval and binop1" [] (Bin(And,Bool(true),Bool(true))) (VBool(true));
    make_eval_test "eval and binop2" [] (Bin(And,Bool(true),Bool(false))) (VBool(false));
    make_eval_test "eval and binop3" [] (Bin(And,Bool(false),Bool(false))) (VBool(false));
    make_eval_test "eval or binop" [] (Bin(Or,Bool(false),Bool(false))) (VBool(false));
    make_eval_test "eval or binop2" [] (Bin(Or,Bool(true),Bool(false))) (VBool(true));
    make_eval_test "eval or binop3" [] (Bin(Or,Bool(true),Bool(true))) (VBool(true));
    make_eval_test "eval lt binop" [] (Bin(Lt,Int(5),Int(10))) (VBool(true));
    make_eval_test "eval lt binop2" [] (Bin(Lt,Int(10),Int(5))) (VBool(false));
    make_eval_test "eval le binop" [] (Bin(Le,Int(5),Int(10))) (VBool(true));
    make_eval_test "eval le binop2" [] (Bin(Le,Int(10),Int(5))) (VBool(false));
    make_eval_test "eval le binop3" [] (Bin(Le,Int(10),Int(10))) (VBool(true));
    make_eval_test "eval gt binop" [] (Bin(Gt,Int(5),Int(10))) (VBool(false));
    make_eval_test "eval gt binop2" [] (Bin(Gt,Int(10),Int(5))) (VBool(true));
    make_eval_test "eval ge binop" [] (Bin(Ge,Int(5),Int(10))) (VBool(false));
    make_eval_test "eval ge binop2" [] (Bin(Ge,Int(10),Int(5))) (VBool(true));
    make_eval_test "eval ge binop3" [] (Bin(Ge,Int(10),Int(10))) (VBool(true));
    make_eval_test "eval eq binop" [] (Bin(Eq,Int(10),Int(10))) (VBool(true));
    make_eval_test "eval eq binop2" [] (Bin(Eq,Str("hello"),Str("hello"))) (VBool(true));
    make_eval_test "eval eq binop3" [] (Bin(Eq,Int(10),Int(9))) (VBool(false));
    make_eval_test "eval eq binop4" [] (Bin(Eq,Str("hello"),Str("hello world"))) (VBool(false));
    make_eval_test "eval ne binop" [] (Bin(Ne,Str("hello"),Str("hello world"))) (VBool(true));
    make_eval_test "eval ne binop2" [] (Bin(Ne,Int(10),Int(9))) (VBool(true));
    make_eval_test "eval cat binop" [] (Bin(Cat,Str("hello "),Str("world"))) (VStr("hello world"));

    make_eval_test "eval una int" [] (Una(Neg,Int(42))) (VInt(-42));
    make_eval_test "eval una bool" [] (Una(Not,Bool(true))) (VBool(false));
    make_eval_test "eval seq" [] (Seq(Unit,Bool(true))) (VBool(true));
    make_eval_test "eval ifthen true" [] 
      (IfThen(Bool(true),Int(6),Int(9))) (VInt(6));
    make_eval_test "eval ifthen false" [] 
      (IfThen(Bool(false),Int(6),Int(9))) (VInt(9));
    make_eval_test "eval match 1" [] 
      (Match(Int(50),[(PInt(50),Bool(true)); (PWild,Bool(false))])) 
      (VBool(true));
    make_eval_test "eval match 2" [] 
      (Match(Int(50),[(PInt(51),Bool(true)); (PWild,Bool(false))])) 
      (VBool(false));

    make_eval_test_exn "eval string_of_int app exn" [] 
      (App(Var("string_of_int"), Bool(true))) (ExpectedInt);
    make_eval_test_exn "eval sleep app exn" [] 
      (App(Var("sleep"), Bool(true))) (ExpectedInt);
    make_eval_test_exn "eval random app exn" [] 
      (App(Var("random"), Bool(true))) (ExpectedInt);   
    make_eval_test_exn "eval assign exn" [] 
      (Assign(Int(2), Int(3))) (ExpectedRef);
  ]

let _ = run_test_tt_main suite
