open Dwt.Infix
open Types
open Pretty

exception ExpectedUnit
exception ExpectedBool
exception ExpectedInt
exception ExpectedFunction
exception ExpectedHandle
exception ExpectedPromise
exception ExpectedRef
exception ExpectedList
exception ExpectedString
exception UnboundVariable
exception InexhaustivePatterns
exception IncompatibleTypes
exception ArgumentMismatch
exception LetMismatch
exception AwaitMismatch

(**[check_prom_lst v] checks if the list is a list of promises  *)
let rec check_prom_lst v = begin match v with 
  | VCons(v1,v2) -> begin match v1,v2 with 
      | VDwt(p), VNil -> true
      | VDwt(p),VCons(nv1,nv2) -> check_prom_lst (VCons(nv1,nv2))
      | _,_ -> false end
  | _ -> raise ExpectedList end

(**[make_prom_lst v acc] makes a list of promises  *)
let rec make_prom_lst v acc = begin match v with 
  | VCons(v1,v2) -> begin match v1,v2 with 
      | VDwt(p), VNil -> acc@[p]
      | VDwt(p),VCons(nv1,nv2) -> make_prom_lst (VCons(nv1,nv2)) (acc@[p])
      | _,_ -> failwith "error" end
  | _ -> raise ExpectedList end

(**[make_val_lst lst acc] makes a list of values *)
let rec make_val_lst lst acc = match lst with 
  | [] -> acc 
  | h::t -> make_val_lst t (VCons(h,acc))

(* [eval env exp] is [v], where [v] is the result of evaluating [exp] under the
 * environment [env]
 * side effects: produces the applicable i/o side effects *)
let rec eval (env : env) (exp : exp) : value =
  match exp with 
  | Unit -> VUnit
  | Bool b -> VBool (b)
  | Pair (exp1,exp2) -> VPair (eval env exp1, eval env exp2)
  | Int (i) -> VInt(i)
  | Str s -> VStr(s)
  | Var v -> (try (List.assoc v env) with |Not_found -> raise UnboundVariable)
  | Fun(p,exp) -> VFun(p,exp,env)
  | App (exp1,exp2) -> begin
      match exp1 with 
      | Var "print" -> let v2 = eval env exp2 in let s = Pretty.print(v2) in 
      (print_string(s);flush_all();VUnit)
      | Var "println" -> let v2 = eval env exp2 in let s = Pretty.print(v2) in
       (print_string( s ^ "\n" );flush_all();VUnit)
      | Var "print_detail1" -> let v2 = eval env exp2 in 
      let s = Pretty.print_detail1(v2) in (print_string(s);flush_all();VUnit)
      | Var "print_detail2" -> let v2 = eval env exp2 in 
      let s = Pretty.print_detail2(v2) in (print_string(s);flush_all();VUnit)
      | Var "print_detail3" -> let v2 = eval env exp2 in 
      let s = Pretty.print_detail3(v2) in (print_string(s);flush_all();VUnit)
      | Var "string_of_int" -> begin match eval env exp2 with
          | VInt(i) -> VStr(string_of_int(i))
          | _ -> raise ExpectedInt end
      | Var "sleep" -> begin match eval env exp2 with
          | VInt(i) ->  
          VDwt(Dwt.bind (Dwt.sleep i) (fun p -> Dwt.return VUnit))
          | _ -> raise ExpectedInt end
      | Var "random" -> begin match eval env exp2 with
          | VInt(i) -> if i>0 then VInt(Random.int i) else 
          raise (Invalid_argument "integer n not greater than 0")
          | _ -> raise ExpectedInt end
      | Var "ignore" -> (ignore (eval env exp2));VUnit
      | _ -> begin match eval env exp1 with 
          | VFun(p,exp,env')  -> begin let v2 = eval env exp2 in 
          match bind_pat p v2 with 
            |None -> raise ArgumentMismatch
            |Some x -> eval (List.append x env') exp end
          | VFunRec(p,exp,envref) -> begin let v2 = eval env exp2 in 
          match bind_pat p v2 with 
            |None -> raise ArgumentMismatch
            |Some x -> eval (List.append x (!envref) ) exp end
          | _ -> raise ExpectedFunction end
    end
  | Let (pat, exp1, exp2) -> begin match bind_pat pat (eval env exp1) with 
      |Some x -> eval (x@env) exp2
      |None -> raise LetMismatch end
  |LetRec(var,exp1,exp2) -> begin match eval env exp1 with 
      | VFun(p,exp,env')  ->  (let temp_env = ref env' in 
      let closure = VFunRec(p,exp,temp_env) in 
let newenv = ((var,closure)::env') in temp_env := newenv; eval !temp_env exp2 )
      | _ -> raise ExpectedFunction end
  | Nil -> VNil 
  | Cons (exp1,exp2) -> VCons (eval env exp1, eval env exp2)
  | Assign (exp1,exp2) -> begin let loc =  eval env exp1 in 
  let v2 = eval env exp2 in match loc with 
    | VRef(r) -> (r := v2);VUnit 
    | _ -> raise ExpectedRef end   
  | Ref (exp) -> (let v1 = eval env exp in VRef(ref v1) )
  | Deref (exp) -> begin match eval env (exp) with 
      | VRef(r) -> !r
      | _ -> raise ExpectedRef end
  | Bin (bin, exp1, exp2) -> begin let v1 = eval env exp1 in 
  let v2 = eval env exp2 in 
      (match bin,v1,v2 with 
       | Add,VInt(i1),VInt(i2) -> VInt(i1+i2)
       | Add, _, _ -> raise ExpectedInt
       | Sub, VInt(i1),VInt(i2) -> VInt(i1-i2)
       | Sub, _, _ -> raise ExpectedInt
       | Mul,VInt(i1),VInt(i2) -> VInt(i1*i2)
       | Mul, _, _ -> raise ExpectedInt
       | Div,VInt(i1),VInt(i2) -> VInt(i1/i2)
       | Div, _, _ -> raise ExpectedInt
       | Mod,VInt(i1),VInt(i2) -> VInt(i1 mod i2)
       | Mod, _, _ -> raise ExpectedInt
       | And,VBool(b1),VBool(b2) -> VBool(b1&&b2)
       | And, _, _ -> raise ExpectedBool
       | Or,VBool(b1),VBool(b2) -> VBool(b1||b2)
       | Or, _, _ -> raise ExpectedBool
       | Lt,VInt(i1),VInt(i2) -> VBool(i1<i2)
       | Lt, _, _ -> raise ExpectedInt
       | Le,VInt(i1),VInt(i2) -> VBool(i1<=i2)
       | Le, _, _ -> raise ExpectedInt
       | Gt,VInt(i1),VInt(i2) -> VBool(i1>i2)
       | Gt, _, _ -> raise ExpectedInt
       | Ge,VInt(i1),VInt(i2) -> VBool(i1>=i2)
       | Ge, _, _ -> raise ExpectedInt
       | Eq,VInt(i1),VInt(i2) -> VBool(i1=i2)
       | Eq,VStr(s1),VStr(s2) -> VBool(s1=s2)
       | Eq,VBool(b1),VBool(b2) -> VBool(b1=b2)
       | Eq,_,_ -> raise IncompatibleTypes
       | Ne,VInt(i1),VInt(i2) -> VBool(i1<>i2)
       | Ne,VStr(s1),VStr(s2) -> VBool(s1<>s2)
       | Ne,VBool(b1),VBool(b2) -> VBool(b1<>b2)
       | Ne,_,_ -> raise IncompatibleTypes
       | Cat,VStr(s1),VStr(s2) -> VStr(s1^s2)
       | Cat, _, _ -> raise ExpectedString
      ) end
  | Una (una, exp) -> begin match una,(eval env exp) with 
      | Neg,VInt(i) ->VInt(-i)
      | Neg, _ -> raise ExpectedInt
      | Not,VBool(b) -> VBool(not b)
      | Not, _ -> raise ExpectedBool
    end
  | Seq (exp1,exp2) -> ignore (eval env exp1);(eval env exp2) 
  | IfThen (exp1, exp2, exp3) -> begin match eval env exp1 with 
      | VBool(b) -> if b=true then eval env exp2 else eval env exp3 
      | _ -> raise ExpectedBool
    end
  | Match (exp, lst) -> begin let v1 =  eval env exp in
      match lst with 
      | [] -> raise InexhaustivePatterns
      | (p,e1)::t -> begin match bind_pat p v1 with 
        | Some x -> eval (x@env) e1
        | None -> eval env (Match(exp,t)) end
    end 
  | Await (pat,exp1,exp2) ->  begin match eval env exp1 with 
      | VDwt(prom1) -> let prom2 = Dwt.bind prom1 (fun v1 -> begin 
      match bind_pat pat v1 with 
          | Some x -> begin match eval (x@env) exp2 with 
                      |VDwt(p2) -> p2  
                      | _ -> raise ExpectedPromise end
          | None -> raise AwaitMismatch end)  in VDwt(prom2)
      | _ -> raise ExpectedPromise
    end
  | Spawn (exp1, exp2) -> begin match eval env exp1 with 
      | VFun (p,en,exp) ->  
VHandle(Dwt.spawn (Serialize.string_of_value (eval env exp1)) 
(Serialize.string_of_value (eval env exp2))  ) 
      | VFunRec (p,en,expref) ->  
      VHandle(Dwt.spawn (Serialize.string_of_value (eval env exp1)) 
      (Serialize.string_of_value (eval env exp2))  ) 
      | _ -> raise ExpectedFunction
    end
  | Send (exp1,exp2) -> begin match (eval env exp1), (eval env exp2) with 
      | v,VHandle(hand) -> 
      (Dwt.send (Serialize.string_of_value v) hand); VUnit
      | _,_ -> failwith "error"
    end
  | Recv(exp) -> begin match eval env exp with 
      | VHandle(hand) -> 
      VDwt( Dwt.bind (Dwt.recv hand) 
      (fun v -> Dwt.return(Serialize.value_of_string v)) )
      | _ -> raise ExpectedHandle
    end
  | Join(exp) -> begin match eval env exp with 
      | VNil -> VDwt (Dwt.return VNil)
      | VCons(v1,v2) -> begin match check_prom_lst (VCons(v1,v2)) with 
          | true -> let lst = make_prom_lst (VCons(v1,v2)) [] in 
VDwt(Dwt.bind (Dwt.join lst) (fun lst -> Dwt.return (make_val_lst lst VNil)) ) 
          | false -> raise ExpectedPromise end
      | _ -> raise ExpectedList
    end
  | Pick(exp) -> begin match eval env exp with 
      | VNil -> VDwt (Dwt.return VNil)
      | VCons(v1,v2) -> begin match check_prom_lst (VCons(v1,v2)) with 
          | true -> let lst = make_prom_lst (VCons(v1,v2)) [] in 
          VDwt(Dwt.pick lst)
          | false -> raise ExpectedPromise end
      | _ -> raise ExpectedList
    end
  | Return(exp) -> VDwt(Dwt.return (eval env exp))


(* [bind_pat p v] is [None] where [v] does not match [p], and [Some b]
 * where [v] matches [p] producing new bindings [b] *)
and bind_pat (p : pat) (v : value) : env option = begin
  match p,v with 
  | PUnit,VUnit -> Some []
  | PWild, _ -> Some []
  | PBool b1, VBool b2 -> if b1=b2 then Some [] else None
  | PInt i1, VInt i2 -> if i1=i2 then Some [] else None
  | PStr s1, VStr s2 -> if s1=s2 then Some [] else None 
  | PVar var, v -> Some [(var,v)]
  | PPair (p1,p2), VPair(v1,v2) -> begin 
  match (bind_pat p1 v1), (bind_pat p2 v2) with 
      | Some x, Some y -> Some (y@x)
      | _ -> None 
    end
  | PNil,VNil -> Some []
  | PCons (p1,p2), VCons(v1,v2) -> begin 
  match (bind_pat p1 v1), (bind_pat p2 v2) with 
      | Some x, Some y -> Some (y@x)
      | _ -> None
    end
  | _ -> None 
end
(* You may use the following utility functions in your implementation.
 * Example usage: [eval env exp |> assert_unit] *)

and assert_unit = function
  | VUnit -> ()
  | v -> raise ExpectedUnit

and assert_bool = function
  | VBool b -> b
  | _ -> raise ExpectedBool

and assert_int = function
  | VInt i -> i
  | _ -> raise ExpectedInt

and assert_fun = function
  | VFun (f, b, env) -> (f, b, env)
  | _ -> raise ExpectedFunction

and assert_handle = function
  | VHandle h -> h
  | _ -> raise ExpectedHandle

and assert_dwt = function
  | VDwt dwt -> dwt
  | _ -> raise ExpectedPromise

and assert_ref = function
  | VRef ref -> ref
  | _ -> raise ExpectedRef

and assert_list vs =
  match vs with
  | VNil | VCons _ -> vs
  | _ -> raise ExpectedList

and assert_string = function
  | VStr s -> s
  | _ -> raise ExpectedString

(* Converts a list into a VList. *)
and vlist_of_list l =
  let rec loop acc = function
    | [] -> acc
    | h::t -> loop (VCons(h,acc)) t in
  loop VNil (List.rev l)


